from pathlib import Path
from subprocess import run
import sys
from tempfile import TemporaryDirectory
import unittest
from xml.etree.ElementTree import parse
import json

from curve_audit.common import ROOT


class EffectMetricsTests(unittest.TestCase):
    def test_offline_build_reproduces_the_registered_figures_and_metrics(self):
        directory = ROOT / 'audit/effect_metrics'
        command = [sys.executable, '-B', str(directory / 'build.py')]
        with TemporaryDirectory() as folder:
            output = Path(folder) / 'metrics'
            run([*command, '--output', str(output)], check=True, cwd=folder)
            saved = directory / 'figures'
            self.assertEqual(sorted(p.name for p in output.iterdir()), sorted(p.name for p in saved.iterdir()))
            for path in saved.iterdir():
                with self.subTest(file=path.name):
                    self.assertEqual(path.read_bytes(), (output / path.name).read_bytes())
                    if path.suffix == '.svg':
                        self.assertTrue(parse(output / path.name).getroot().tag.endswith('}svg'))
            metrics = json.loads((output / 'metrics.json').read_bytes())
            self.assertEqual(metrics['pair_counts'], {'scheduled_pairs': 18, 'completed_pairs': 16})
            self.assertEqual(len(metrics['quote_points']), 50)
            rows = {(r['experiment'], r['cohort'], r['scope'], r['group'], r['metric']): r
                    for r in metrics['metrics']}
            self.assertEqual(rows['formal', 'scheduled', 'overall', 'E minus G',
                                  'reproducible_correct_delta']['value'], 18.75)
            self.assertEqual(rows['research_decisions', 'scheduled', 'E', 'verified',
                                  'wrong_sent_to_review']['denominator'], 0)
            self.assertIsNone(rows['research_decisions', 'scheduled', 'E', 'verified',
                                   'wrong_sent_to_review']['value'])
            self.assertEqual(rows['arithmetic_faults', 'shared_verifier_bug', 'overall', 'after',
                                  'published']['numerator'], 0)
            rejected = run([*command, '--output', str(output)], cwd=folder, capture_output=True)
            self.assertNotEqual(rejected.returncode, 0)
            self.assertEqual((output / 'metrics.json').read_bytes(), (saved / 'metrics.json').read_bytes())
