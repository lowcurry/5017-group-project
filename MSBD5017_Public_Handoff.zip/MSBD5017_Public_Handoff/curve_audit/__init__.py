"""Auditable historical Curve investigation. No network calls on import."""
__version__ = "2.0.0"
