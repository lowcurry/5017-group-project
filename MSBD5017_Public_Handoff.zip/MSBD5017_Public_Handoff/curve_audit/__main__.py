from .confirmation_cli import main

raise SystemExit(main())
