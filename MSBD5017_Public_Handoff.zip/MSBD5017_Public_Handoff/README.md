# MSBD 5017 · Curve 3pool Evidence and Verification

WANG Hanyang · HE Yuequn · WU Yuxuan

This public handoff archive contains the final report, implementation, frozen historical observations and experiment records for an independently verifiable stablecoin liquidity investigation agent.

## Start here

- `report/MSBD5017_Final_Report.pdf` is the technical report.
- `presentation/` contains the slide deck and the demonstration and rehearsal notes.
- `experiments/formal_v1/result_summary.json` contains the structured results for the 36 scheduled model runs and six template outputs. The two model budget stops are retained. Raw reports, verification decisions, publication records and frozen sources are in the same directory.
- `audit/` contains the initial prose evidence review and its counting rules. `audit/prose_review_20261110/` summarizes the two prose reviews and reconciliation. `audit/reference_review_20261109/` documents the separate benchmark review and its 18-component comparison.
- `data/current_study/` contains raw historical RPC responses. `results/current_preparation/` contains the frozen task and data bindings, reference answers and review provenance.
- `results/current_chain/anchor.json` contains the saved local-chain receipt. It attests to the package commitment used in the demonstration.

## Reproduce offline

Extract the archive and open a terminal in the project directory. Python 3.10 or newer is sufficient. Run the inventory check on a fresh extraction, before installing dependencies or creating any files. These commands work without network access or credentials and preserve the frozen records.

```sh
python3 -B docs/verify_delivery.py .
python3 -B docs/reproduce_current.py
python3 -B -m curve_audit replay
python3 -B -m unittest discover -s tests
```

The first command checks the exact file inventory and manifest hashes. The second replays the raw source captures, deterministic engineering demonstration and separate synthetic fault suite. Its `formal_model_outputs` value counts new generation during that offline command. The third command checks the frozen source and data hashes, recomputes V1/V2 decisions and publication outcomes, reconciles the recorded formal group totals, and repeats the 64 verifier decisions across the 32 frozen fault cases. The archived model transcripts provide the original outputs. The original `python3 -B docs/verify_formal_replay.py` command runs the same replay.

The archived `experiments/formal_v1/fault_batch.py` records the original run and uses paths from that environment. Run `python3 -B -m curve_audit replay` on a fresh extraction. For the final interpretation, see `experiments/formal_v1/verifier_replay_20261105.json` for the corrected source-conflict verdicts and `audit/prose_review_20261110/REVIEW.md` for the completed prose review. `result_summary.json` and `fault_batch/summary.json` preserve the original run's statuses and verdicts.

If you install the project from a working copy, the `curve-audit` command exposes `replay` and `verify`. Run it from the extracted handoff directory or use `curve-audit replay --root PATH`. The `legacy` subcommand and `docs/confirmation_protocol.md` are for the historical eight-task prototype.

The packaged verifier validates the report envelope, enforces task-defined dependencies and checks the two bound source roles against separate raw provider records. These safeguards were added after the study. The historical runner and evidence are preserved in the formal archive. The recorded verifier results and publication totals also replay with the packaged implementation. `audit/RESOURCE_USE.md` documents archived model and RPC usage, the new local measurements of the packaged verifier and publisher, and gaps in the cost records.

For a single report, run the verifier with `--output` pointing to a new file. The `published` JSON contains only checked claim fields. The `freeze` and `run` commands of `python3 -B -m curve_audit.current_runner` accept an optional `--source-dir` for raw provider captures. The default is inferred from the preparation directory.

```sh
python3 -B -m curve_audit verify \
  --preparation results/current_preparation --task R02 \
  --report experiments/formal_v1/R02_T.json \
  --output /tmp/5017-new-verification.json \
  --secondary-sources data/current_study/usdc_2023_drpc_erc20.json \
                      data/current_study/ftx_2022_drpc_erc20.json
```

The prose evidence review can also be regenerated to a separate directory.

```sh
python3 -B audit/recompute_prose_audit.py . --output /tmp/5017-prose-review
```

## Follow-up checks

- [Scheduled and completed-pair comparison](audit/FORMAL_SENSITIVITY.md) reports the same frozen runs overall and by event. Run `python3 -B audit/compare_run_sets.py` from this directory.
- [Cost ledger and offline timing](audit/cost_trace_20261111/README.md) covers saved input loading through local output validation and supplies a ledger for logging actual stages, retries, usage and fees in a future live run.
- [Supplementary verifier checks](audit/verification_extension_20261111/README.md) covers refusal reason codes, additional window checks and injected faults in a separate offline exercise.
- [Historical decision replay](audit/decision_replay_20261112/README.md) measures errors intercepted and correct actions sent to review across 36 research decisions. It also tests quote eligibility at 50 historical blocks for a hypothetical 100,000 USDC order. Run `python3 -B audit/decision_replay_20261112/replay.py .`.

The follow-up checks use archived inputs. The formal score still uses the original scheduled comparison.

To create a fresh local-chain demonstration, install the pinned optional Node dependencies, then write the receipt to a new path. The command rejects an existing output file or symbolic link.

```sh
pnpm install --frozen-lockfile --ignore-scripts
node contracts/anchor.mjs results/current_demo/manifest.json /tmp/5017-new-anchor.json
pnpm test:contract
```

The Ganache chain runs locally. V2 checks separately bound Alchemy and dRPC captures, including the distinct provider identities recorded in the raw files. Equal normalized data is expected when both endpoints agree. The source replay checks the included recordings. Historical data and model call results are preserved in the archive. The development budget optimization has its own folder at `results/optimization_20261105/`.

## Background and scope

The final freeze defines 16 answerable and two non-answerable components, superseding the planning figures. The separate development optimization note is in `output/`. The workbook and attestation under `results/current_preparation/reference_review/` document the consolidated human reference used at the formal freeze. The two later workbooks cover all 18 reference components. The team confirmed that He Yuequn adjudicated R06/S2 on 9 November 2026 and accepted A's result. The comparison and decision are recorded in `audit/reference_review_20261109/REVIEW.md`. The secondary prose evidence review uses its own method and denominator.

The package manifest records hashes of the files delivered here. Compare the ZIP with its adjacent `SHA256SUMS.txt` before extraction, then use the package verifier to check the extracted file set. Keep generated files outside that file set or run the Python examples with `-B` to avoid writing bytecode caches.
