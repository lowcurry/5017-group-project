# MSBD 5017 · Curve 3pool Evidence and Verification

WANG Hanyang · HE Yuequn · WU Yuxuan

This public handoff archive contains the final report, implementation, frozen historical observations and experiment records for an independently verifiable stablecoin liquidity investigation agent.

## Start here

- `report/MSBD5017_Final_Report.pdf` is the technical report.
- `presentation/` contains the slide deck and the demonstration and rehearsal notes.
- `experiments/formal_v1/result_summary.json` contains the structured results for the 36 scheduled model runs and six template outputs. The two model budget stops are retained. Raw reports, verification decisions, publication records and frozen sources are in the same directory.
- `audit/` contains the secondary prose evidence review, its counting rules and the rows used to compute its results.
- `data/current_study/` contains raw historical RPC responses. `results/current_preparation/` contains the frozen task and data bindings, reference answers and review provenance.
- `results/current_chain/anchor.json` contains the saved local-chain receipt. It attests to the package commitment used in the demonstration.

## Reproduce offline

Extract the archive and open a terminal in the project directory. Python 3.10 or newer is sufficient. Run the inventory check on a fresh extraction, before installing dependencies or creating any files. These commands work without network access or credentials and preserve the frozen records.

```sh
python3 -B docs/verify_delivery.py .
python3 -B docs/reproduce_current.py
python3 -B docs/verify_formal_replay.py
python3 -B -m unittest discover -s tests
```

The first command checks the exact file inventory and manifest hashes. The second replays the raw source captures, deterministic engineering demonstration and separate synthetic fault suite. Its `formal_model_outputs` value counts new generation during that offline command. The third command checks the frozen source and data hashes, recomputes V2 decisions and publication outcomes, reconciles the recorded formal group totals, and repeats the 64 verifier decisions across the 32 frozen fault cases. Use this command to replay the archived fault batch. The archived model transcripts provide the original outputs.

The packaged verifier validates the report envelope, enforces task-defined dependencies and checks the two bound source roles against separate raw provider records. These safeguards were added after the study. The historical runner and evidence are preserved in the formal archive. The recorded verifier results and publication totals also replay with the packaged implementation. The post-study offline timing sample is in `results/submission_validation/verifier_timing.json`; it does not measure live acquisition or monetary cost.

For a single report, run the verifier with `--output` pointing to a new file. The `published` JSON contains only checked claim fields. The `freeze` and `run` commands of `python3 -B -m curve_audit.current_runner` accept an optional `--source-dir` for raw provider captures. The default is inferred from the preparation directory.

```sh
python3 -B -m curve_audit.current_verify \
  --preparation results/current_preparation --task R02 \
  --report experiments/formal_v1/R02_T.json \
  --output /tmp/5017-new-verification.json \
  --secondary-sources data/current_study/usdc_2023_drpc_erc20.json \
                      data/current_study/ftx_2022_drpc_erc20.json
```

The prose evidence review can also be regenerated to a separate directory.

```sh
python3 -B audit/recompute_prose_audit.py . --output /tmp/5017-prose-review
```

To create a fresh local-chain demonstration, install the pinned optional Node dependencies, then write the receipt to a new path.

```sh
pnpm install --frozen-lockfile --ignore-scripts
node contracts/anchor.mjs results/current_demo/manifest.json /tmp/5017-new-anchor.json
```

The Ganache chain runs locally. V2 checks separately bound Alchemy and dRPC captures, including the distinct provider identities recorded in the raw files. Equal normalized data is expected when both endpoints agree. The source replay checks the included recordings. Historical data and model call results are preserved in the archive. The development budget optimization has its own folder at `results/optimization_20261105/`.

## Background and scope

The original proposal, teacher feedback and internal planning notes are held by the team. The separate development optimization note is in `output/`. The frozen formal results and the complete prose review are in their dedicated folders above. The workbook and attestation under `results/current_preparation/reference_review/` document the consolidated human reference review. The secondary prose evidence review uses its own method and denominator.

The package manifest records hashes of the files in this public archive. Use the repository’s `SHA256SUMS.txt` to check the ZIP before extraction and the package verifier to check the extracted file set. Keep generated files outside that file set or run the Python examples with `-B` to avoid writing bytecode caches.
