"""V1/V2 replay commands; second endpoint failure yields UNKNOWN."""
import argparse,copy,json
from pathlib import Path
from .common import read_json,write_json
from .current_study import allowed_data,combine_sources,compute,replay_claim,equal,publish

def verify_v2(primary,secondary,task,report):
    checks={};first={r['target_timestamp_utc']:r for r in allowed_data(primary,task)['snapshots']}
    second={r['target_timestamp_utc']:r for r in allowed_data(secondary,task)['snapshots']} if secondary else {}
    for claim in report.get('claims',[]):
        cid=claim.get('claim_id');check=replay_claim(primary,task,claim)
        if check['verdict']=='PASS':
            expected=check['expected'];ids=set(expected['evidence_ids'])
            needed=[r for r in first.values() if 'E_'+r['id'] in ids]
            if not needed or any(r['target_timestamp_utc'] not in second for r in needed):check={'verdict':'UNKNOWN','reason':'secondary_source_unavailable'}
            elif any(any(r.get(k)!=second[r['target_timestamp_utc']].get(k) for k in ['block_number','block_hash','raw_balances','raw_quotes','calldata']) for r in needed):check={'verdict':'FAIL','reason':'secondary_source_state_mismatch'}
            else:
                try:
                    actual=compute(allowed_data(secondary,task),claim['query'],independent=True)
                    if claim.get('unit')!=actual['unit'] or not equal(claim['value'],actual['value'],claim['query']['metric']):check={'verdict':'FAIL','reason':'secondary_recomputation_mismatch'}
                    else:check={**check,'source_recomputed':True,'secondary_value':actual['value']}
                except (ValueError,KeyError):check={'verdict':'UNKNOWN','reason':'secondary_recomputation_unavailable'}
        checks[cid]=check
    return checks

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--preparation',type=Path,required=True);p.add_argument('--task',required=True);p.add_argument('--report',type=Path,required=True)
    p.add_argument('--secondary-sources',type=Path,nargs='*');p.add_argument('--output',type=Path,required=True);a=p.parse_args(argv)
    primary=read_json(a.preparation/'dataset.json');tasks=read_json(a.preparation/'tasks.json');task=next(t for t in tasks if t['task_id']==a.task)
    record=read_json(a.report);report=record.get('report',record)
    secondary=None;reason=None
    if a.secondary_sources:
        try:secondary,_=combine_sources(a.secondary_sources)
        except ValueError as exc:reason=str(exc)
    v1={c.get('claim_id'):replay_claim(primary,task,c) for c in report.get('claims',[])}
    v2=verify_v2(primary,secondary,task,report)
    published,_=publish(primary,task,report,checks_override=v2)
    write_json(a.output,{'V1':v1,'V2':v2,'published':published,'secondary_error':reason,'scope':'structured numerical claims; free prose requires human review'})
    print(json.dumps({'output':str(a.output),'V1_pass':sum(c['verdict']=='PASS' for c in v1.values()),'V2_pass':sum(c['verdict']=='PASS' for c in v2.values())}));return 0
if __name__=='__main__':raise SystemExit(main())
